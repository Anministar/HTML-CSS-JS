const btn5El = document.querySelector('.btn5');
const btn4El = document.querySelector('.btn4');
const btn3El = document.querySelector('.btn3');
const btn2El = document.querySelector('.btn2');
const btn1El = document.querySelector('.btn1');
const signUpEl = document.querySelector('.signUp');


signUpEl.addEventListener('click',function(){
  alert("저장완료!");
})
btn1El.addEventListener('click',function(){
  alert("수정완료!");
})
btn2El.addEventListener('click',function(){
  alert("수정불가!");
})
btn3El.addEventListener('click',function(){
  alert("수정완료!");
})
btn4El.addEventListener('click',function(){
  alert("수정불가!");
})
btn5El.addEventListener('click',function(){
  alert("수정완료!");
})